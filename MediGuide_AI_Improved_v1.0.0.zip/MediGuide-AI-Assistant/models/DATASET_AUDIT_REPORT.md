# Dataset audit report

Generated: 2026-10-24T22:44:55+00:00

## Corpus integrity

- Training rows: **11,977**
- Unique conditions: **647**
- Symptom features: **1,495**
- Unique symptom vectors: **11,971**
- Duplicate vector groups: **5**
- Conflicting-label vector groups: **5**
- Conditions with one example: **533**
- Conditions with at least two examples: **114**

## Interpretation

The source data contains generated and imported symptom profiles rather than independently collected patient outcomes. These checks identify data quality issues but do not establish medical validity or clinical diagnostic accuracy.

## Conflicting identical symptom vectors

The following labels share identical symptom vectors. They are flagged for expert review and are not automatically merged because similar symptoms can occur in distinct conditions.

- `f5a19d840e7f4dec` (2 rows): Gastroesophageal Reflux Disease (GERD); Gastroesophageal reflux (GERD)
- `447b941f39f7867f` (2 rows): Acute Bronchospasm; Asthma exacerbation (possible)
- `96a2b3bc7ebcc59c` (2 rows): Low-Tension Glaucoma; Normal-Tension Glaucoma
- `c9c393a837f56302` (3 rows): Parotid stones; Submandibular stones; Wharton's duct stones
- `07f05af4d610c151` (2 rows): Pleomorphic adenoma; Warthin tumor

## Grouped synthetic holdout benchmark

- Evaluated: date not recorded
- Protocol: Per-class 20% holdout of unique symptom vectors; all rows sharing a held-out vector are excluded from training.
- Training rows: 9,697; test unique patterns: 2,280
- Classes with evaluable held-out patterns: 114
- Top-1 accuracy: 97.018%
- Top-3 accuracy: 99.298%
- Macro F1: 0.9156
- Weighted F1: 0.9719

**Not clinical accuracy.** The benchmark uses generated/imported profiles and cannot substitute for a separate, clinically reviewed patient-level test cohort.
